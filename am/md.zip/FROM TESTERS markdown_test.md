This is *Italic*, so is _this_.

This is **Bold**, so is __this__.

__*Styles* can *be* combined.__

text_with_floor

# 1 Type of heading 1

2 Type of heading 1
=

## 1 Type of heading 2

2 Type of heading 2
-

###### This type of heading can go up to 6

Horizontal Rule is seperated with empty line

---
Horizontal Rule is seperated with empty line

***

Horizontal Rule is seperated with empty line

___

There is no back slash here\
There is no  
double blank space here.

The text below

> is a quote
>> this is a quote inside a quote

>This is a
>
>large block of quote

Unordered list:
- only 1 - test
* only 1 * test
+ only 1 + test

\\ only 1 back slash is visable

\## There are two #tags

# *italic* \*two stars are visable\*

#                  blank spaces are ignored          

# no hash tags in this line are visable ##################################
           
Ordered list:
1. starts with 1
4. as long as
56. rest is a number
2. it will have a order
  1. before the number can be up to two blank spaces
 
Mixed list:
1) item 1
   - sublist
   - three spaces before '-'
2) item 2 
   - sublist

2017\. \ can't be visable.

Simple link <https://www.xtm-cloud.com>.

This [text](https://www.xtm-cloud.com) is a link.

There can be many words [linked][1] with a reference style [link][1].

[1]:https://www.xtm-cloud.com "link title"

[2]: /url '
this
is
a title
'

[2]

Image
![with alt text](image.png "and with title")

Some `words` can be turned into `inline code`.

Code blocks
    
	Use 4 spaces
	to create a code block

```
another code block
```

~~~this is not taken to translation
code block with
javascript style
~~~

<dl>
  <dt>Raw HTML</dt>
  <dd>can also be used</dd>

  <dt>Markdown in HTML</dt>
  <dd>Does *not* work **very** well. Use HTML <em>tags</em>.</dd>
</dl>

<![CDATA[
function matchwo(a,b)
{
  if (a < b && a < 0) then {
    return 1;

  } else {

    return 0;
  }
}
]]>
no function above is ok